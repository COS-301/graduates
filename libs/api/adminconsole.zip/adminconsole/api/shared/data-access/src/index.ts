export * from './lib/api-adminconsole-repository-data-access.module';
